# News Site

I started with making a wireframe in Figma. Then I started on the HTML. Regarding the CSS I mainly focused on flexbox early on because I thought that it was easier, but i wished that I had started on the grid instead. I believe that it would have been easier to use flexbox after the grid was set. The planning on my part could have been better, I got stuck and had to restart the whole project because of the fact that I worked too much on the CSS before I had the main layout ready, so poor planning on my part. I also made a header in Canva. 

The fact that I was "on my own" to do the full website from scratch based on everything that we were thaught in the curriculum before was hard. I would like to work on the website in sections based on the curriculum, that would have been easier for me I believe. 

If I had more time I would like to be be more specific with details. I notice some things in my prject that is not 100%, but I don't have the time to fix it right now. I would also like to work more on my navigation to make it more fun, and mabe add a bit more animations to the project. 
